import { io } from "./index.js";

export default io;
